package weeksix;

/**
 * The Student class represents a student with a roll number, name, and address.
 * It provides getter and setter methods for each attribute.
 * 
 * @author Aerionna Stephenson
 */
public class Student {
	// student attributes
	private int rollno;
	private String name;
	private String address;

	/**
	 * Constructs a new Student object with the specified roll number, name, and
	 * address.
	 * 
	 * @param rollno  the student's roll number
	 * @param name    the student's name
	 * @param address the student's address
	 */
	public Student(int rollno, String name, String address) {
		this.rollno = rollno;
		this.name = name;
		this.address = address;
	}

	// getters and setters

	/**
	 * Returns the roll number
	 * 
	 * @return roll number
	 */
	public int getRollno() {
		return rollno;
	}

	/**
	 * Sets the roll number
	 * 
	 * @param rollno the new roll number
	 */
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	/**
	 * Returns the name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name
	 * 
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the address
	 * 
	 * @return address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the address
	 * 
	 * @param address the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Returns a string representation of the student.
	 * 
	 * @return a String with the student's roll number, name, and address
	 */
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", address=" + address + "]";
	}

}
